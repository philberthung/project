import streamlit as st
import webbrowser
import requests
import urllib.parse
import time
import plotly.express as px
import plotly.graph_objects as go
import json

# OAuth settings
client_id = "Ov23liTxryC5DAIzStP8"
client_secret = "bf372b10e0e6064de4bf1c99db9f60deb02376a3"
redirect_uri = "http://localhost:8501"  # Streamlit's default port
token_url = "https://github.com/login/oauth/access_token"
auth_url = f"https://github.com/login/oauth/authorize?client_id={client_id}&redirect_uri={redirect_uri}"

# Streamlit app
st.title("Group 1 Performance Dashboard")

# Initialize session state
if "auth_code" not in st.session_state:
    st.session_state.auth_code = None
if "access_token" not in st.session_state:
    st.session_state.access_token = None
if "query_params" not in st.session_state:
    st.session_state.query_params = None
if "selected_repos" not in st.session_state:
    st.session_state.selected_repos = "All"  # Default selection

# Function to get query parameters from URL
def get_query_params():
    try:
        query_params = st.query_params
        return query_params
    except:
        return None

# Step 3: Exchange code for access token
if st.session_state.auth_code and not st.session_state.access_token:
    payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "code": st.session_state.auth_code,
        "redirect_uri": redirect_uri
    }
    headers = {"Accept": "application/json"}

    try:
        response = requests.post(token_url, data=payload, headers=headers)
        token_data = response.json()
        access_token = token_data.get("access_token")
        st.session_state.access_token = access_token
    except Exception as e:
        st.error(f"Error fetching token: {e}")

# Step 4: Fetch issues and pull requests from all repositories for a user/organization
if st.session_state.access_token:
    user_or_org = "COMP3122-Group18"  # Specify user or org
    repos_url = f"https://api.github.com/orgs/{user_or_org}/repos"
    repos_headers = {
        "Authorization": f"token {st.session_state.access_token}"
    }

    try:
        # Fetching all repositories of the specified organization
        repos_response = requests.get(repos_url, headers=repos_headers)
        repositories = repos_response.json()

        if isinstance(repositories, list) and repositories:
            # Store all repository names in a list
            repo_names = [repo['name'] for repo in repositories]
            repo_names.insert(0, "All")  # Add "All" option at the beginning

            # Selectbox for repository selection
            selected_repos = st.selectbox("Select a repository", repo_names, index=repo_names.index(st.session_state.selected_repos))
            st.session_state.selected_repos = selected_repos  # Store selected repo in session state

            issue_counts = {}
            pr_counts = {}
            issues_details = []
            pr_details = []

            # Process data based on repository selection
            if selected_repos == "All":
                # Fetch data from all repositories
                repos_to_process = repositories
            else:
                # Fetch data from the selected repository only
                repos_to_process = [repo for repo in repositories if repo['name'] == selected_repos]

            for repo in repos_to_process:
                repo_name = repo['name']
                # Fetching issues for each repository
                issues_url = f"https://api.github.com/repos/{user_or_org}/{repo_name}/issues"
                issues_response = requests.get(issues_url, headers=repos_headers)
                issues = issues_response.json()

                if isinstance(issues, list) and issues:
                    for issue in issues:
                        username = issue['user']['login']
                        # Separate issues and pull requests
                        if 'pull_request' in issue:  # It's a pull request
                            pr_details.append({
                                "title": issue['title'],
                                "user": username,
                                "url": issue['html_url']
                            })
                            if username in pr_counts:
                                pr_counts[username] += 1
                            else:
                                pr_counts[username] = 1
                        else:  # It's a regular issue
                            issues_details.append({
                                "title": issue['title'],
                                "user": username,
                                "url": issue['html_url']
                            })
                            if username in issue_counts:
                                issue_counts[username] += 1
                            else:
                                issue_counts[username] = 1

            # Create a dashboard layout
            st.header("Performance Metrics")

            # First row: Issues and Pull Requests
            col1, col2 = st.columns(2)

            with col1:
                if issue_counts:
                    st.subheader("Issue Distribution")
                    # Create a pie chart for issues using Plotly
                    fig_issues = px.pie(
                        names=list(issue_counts.keys()),
                        values=list(issue_counts.values()),
                        title="Issues per User",
                        hole=0.4  # Donut chart style
                    )
                    fig_issues.update_traces(textinfo='percent+label', textposition='inside')
                    fig_issues.update_layout(
                        margin=dict(l=20, r=20, t=40, b=20),
                        showlegend=True,
                        height=300
                    )
                    st.plotly_chart(fig_issues, use_container_width=True)
                else:
                    st.write("No issues found to display or visualize.")

            with col2:
                if pr_counts:
                    st.subheader("Pull Request Distribution")
                    # Create a pie chart for pull requests using Plotly
                    fig_pr = px.pie(
                        names=list(pr_counts.keys()),
                        values=list(pr_counts.values()),
                        title="Pull Requests per User",
                        hole=0.4  # Donut chart style
                    )
                    fig_pr.update_traces(textinfo='percent+label', textposition='inside')
                    fig_pr.update_layout(
                        margin=dict(l=20, r=20, t=40, b=20),
                        showlegend=True,
                        height=300
                    )
                    st.plotly_chart(fig_pr, use_container_width=True)
                else:
                    st.write("No pull requests to display or visualize.")

            # Second row: Detailed Metrics (e.g., Total Issues and PRs)
            col3, col4 = st.columns(2)

            with col3:
                st.subheader("Total Issues")
                total_issues = sum(issue_counts.values())
                st.metric(label="Total Issues", value=total_issues)

            with col4:
                st.subheader("Total Pull Requests")
                total_prs = sum(pr_counts.values())
                st.metric(label="Total Pull Requests", value=total_prs)

        else:
            st.write("No repositories found for this organization.")
    except Exception as e:
        st.error(f"Error fetching repositories or issues: {e}")
else:
    # Add a button to initiate GitHub OAuth if not authenticated
    if st.button("Login with GitHub"):
        webbrowser.open(auth_url)
        time.sleep(1)  # Give some time for the redirect
        query_params = get_query_params()
        if query_params and "code" in query_params:
            st.session_state.auth_code = query_params["code"]
            st.experimental_rerun()