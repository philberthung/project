import streamlit as st
import pandas as pd
from pymongo import MongoClient
from pymongo.server_api import ServerApi

# MongoDB connection
uri = "mongodb+srv://nata:isd2025@isdcluster.jnn9ctb.mongodb.net/?appName=ISDcluster"
client = MongoClient(uri, server_api=ServerApi('1'))

# Check connection
try:
    client.admin.command('ping')
    st.success("Connected to MongoDB!")
except Exception as e:
    st.error(f"Could not connect to MongoDB: {e}")

# Access the database and collection
db = client.students_database  # Replace with your database name
students_collection = db.students  # Replace with your collection name

# Load student data
students_data = list(students_collection.find({}))  # Fetch all students
students_df = pd.DataFrame(students_data)

# Streamlit UI
st.title("Student Information")

# Check if the user is logged in and netid is available in session state
if 'logged_in' in st.session_state and st.session_state.logged_in and 'netid' in st.session_state:
    netid = st.session_state.netid

    # Filter the DataFrame to only show the logged-in user's information
    user_data = students_df[students_df['netid'] == netid]  # Assuming 'netid' stores the login email

    if not user_data.empty:
        st.write(f"**ID:** {user_data['id'].iloc[0]}")
        st.write(f"**Name:** {user_data['name'].iloc[0]}")
        st.write(f"**NetID:** {user_data['netid'].iloc[0]}")
        st.write(f"**Role:** {user_data['role'].iloc[0]}")
        st.write(f"**Email:** {user_data['email'].iloc[0]}")
        st.write(f"**Permission:** {user_data['permission'].iloc[0]}")
        st.write(f"**Assigned Group:** {user_data['group'].iloc[0]}")
        #st.dataframe(user_data)  # Display the logged-in user's data  # Removed dataframe
    else:
        st.warning("No data found for the logged-in user.")
else:
    st.info("Please log in to view your information.")