import streamlit as st
import webbrowser
import requests
import urllib.parse
from streamlit.web.server import Server
import time
import matplotlib.pyplot as plt
import json

# OAuth settings
client_id = "Ov23liTxryC5DAIzStP8"
client_secret = "bf372b10e0e6064de4bf1c99db9f60deb02376a3"
redirect_uri = "http://localhost:8501"  # Streamlit's default port
token_url = "https://github.com/login/oauth/access_token"
auth_url = f"https://github.com/login/oauth/authorize?client_id={client_id}&redirect_uri={redirect_uri}"

# Streamlit app
st.title("GitHub Classroom Activity")

# Initialize session state
if "auth_code" not in st.session_state:
    st.session_state.auth_code = None
if "access_token" not in st.session_state:
    st.session_state.access_token = None
if "query_params" not in st.session_state:
    st.session_state.query_params = None

# Function to get query parameters from URL
def get_query_params():
    try:
        query_params = st.query_params
        return query_params
    except:
        return None
    
# Step 3: Exchange code for access token
if st.session_state.auth_code and not st.session_state.access_token:
    payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "code": st.session_state.auth_code,
        "redirect_uri": redirect_uri
    }
    headers = {"Accept": "application/json"}

    try:
        response = requests.post(token_url, data=payload, headers=headers)
        token_data = response.json()
        access_token = token_data.get("access_token")
        st.session_state.access_token = access_token
    except Exception as e:
        st.error(f"Error fetching token: {e}")

# Step 4: Redirect to GitHub authorization page
if st.session_state.access_token:
    user_or_org = "COMP3122-Group18"  # Specify user or org
    repos_url = f"https://api.github.com/orgs/{user_or_org}/repos"
    repos_headers = {"Authorization": f"token {st.session_state.access_token}"}

    try:
        # Fetching all repositories
        repos_response = requests.get(repos_url, headers=repos_headers)
        repositories = repos_response.json()

        if repositories:
            issues_details = []
            pr_details = []
            milestone_details = {}

            # Store all repository names in a list
            repo_names = [repo['name'] for repo in repositories]
            selected_repos = st.selectbox("Select a repository", ["Select a group"] + repo_names)
            
            # Display selected repositories
            if selected_repos != "Select a group":
                repos_name = [selected_repos]  # Single repository as list
                
                issues_url = f"https://api.github.com/repos/{user_or_org}/{selected_repos}/issues"
                issues_response = requests.get(issues_url, headers=repos_headers)
                issues = issues_response.json()
                
                for issue in issues:
                    # Check if the issue is a pull request
                    if 'pull_request' in issue:
                        pr_details.append({"title": issue['title'],"body": issue.get('body', 'No description provided'), "user": issue['user']['login'], "state": issue['state'],
                                            "created_at": issue['created_at'], "updated_at": issue['updated_at'], "url": issue['html_url'], "files_changed": [] })
                    else:
                        issues_details.append({"title": issue['title'], "body": issue.get('body', 'No description provided'), "user": issue['user']['login'], 
                                               "created_at": issue['created_at'], "updated_at": issue['updated_at'], "url": issue['html_url']})
                
                milestones_url = f"https://api.github.com/repos/{user_or_org}/{selected_repos}/milestones"
                milestones_response = requests.get(milestones_url, headers=repos_headers)
                milestones = milestones_response.json()
                print(milestones)
                
                for milestone in milestones:
                    milestone_title = milestone['title']
                    milestone_details[milestone_title] = {
                        "state": milestone['state'],
                        "due_on": milestone['due_on'],
                        "url": milestone['html_url'],
                        "description": milestone.get('description', 'No description provided.'), 
                        "users": [issue['user']['login'] for issue in issues if issue.get('milestone') and issue['milestone']['title'] == milestone_title]
                    }
                         
                # sorted all contents with username
                sorted_issues = sorted(issues_details, key=lambda x: x['user'])
                sorted_prs = sorted(pr_details, key=lambda x: x['user'])
                sorted_milestones = sorted(milestone_details.items(), key=lambda x: x[1]['users'])
                
                select_user = st.selectbox("Select a user", ["All"] + sorted(set(issue['user'] for issue in issues_details + pr_details)))
                
                if select_user != "All":
                    filtered_issues = [issue for issue in sorted_issues if issue['user'] == select_user]
                    filtered_prs = [pr for pr in sorted_prs if pr['user'] == select_user]
                    filtered_milestones = {title: details for title, details in sorted_milestones if select_user in details['users']}
                else:
                    filtered_issues = sorted_issues
                    filtered_prs = sorted_prs
                    filtered_milestones = milestone_details
                
                # Add a radio button to select the content type
                content_type = st.radio(
                    "Select content to view:",
                    ("All", "Issues", "Pull Requests", "Milestones"),
                    horizontal=True
                )

                # Display content based on selection
                if content_type == "All":
                    display_issues = True
                    display_prs = True
                    display_milestones = True
                elif content_type == "Issues":
                    display_issues = True
                    display_prs = False
                    display_milestones = False
                elif content_type == "Pull Requests":
                    display_issues = False
                    display_prs = True
                    display_milestones = False
                elif content_type == "Milestones":
                    display_issues = False
                    display_prs = False
                    display_milestones = True

                # Display issues, pull requests, and milestones with selected user
                if select_user != "All":
                    if display_issues:
                        st.write(f"### Issues by {select_user}:")
                        if filtered_issues:
                            for issue in filtered_issues:
                                st.write(f"**Title:** {issue['title']}")
                                st.write(f"**Body:** {issue['body']}")
                                st.write(f"**User:** {issue['user']}")
                                st.write(f"**Created At:** {issue['created_at']}")
                                st.write(f"**Updated At:** {issue['updated_at']}")
                                st.write(f"**URL:** [Link]({issue['url']})")
                                st.write("---")
                        else:
                            st.write("No issues found for this user.")
                            st.write("---")
                        
                    if display_prs:
                        # Display pull requests of the selected user
                        st.write(f"### Pull Requests by {select_user}:")
                        if filtered_prs:
                            for pr in filtered_prs:
                                st.write(f"**Title:** {pr['title']}")
                                st.write(f"**Body:** {pr['body']}")
                                st.write(f"**User:** {pr['user']}")
                                st.write(f"**State:** {pr['state']}")
                                st.write(f"**Created At:** {pr['created_at']}")
                                st.write(f"**Updated At:** {pr['updated_at']}")
                                st.write(f"**URL:** [Link]({pr['url']})")
                                st.write("---")
                        else:
                            st.write("No pull requests found for this user.")
                            st.write("---")
                        
                    if display_milestones:
                        st.write(f"### Milestones by {select_user}:")
                        if filtered_milestones:
                            for milestone_title, details in filtered_milestones.items():
                                st.write(f"**Milestone Title:** {milestone_title}")
                                st.write(f"**State:** {details['state']}")
                                st.write(f"**Due on:** {details['due_on']}")
                                st.write(f"**Description:** {details['description']}")
                                st.write(f"**URL:** [Link]({details['url']})")
                                st.write("---")
                        else:
                            st.write("No milestones found for this user.")
                            st.write("---")
                        
                else:
                    if display_issues:
                        st.write("### All Issues:")
                        if sorted_issues:
                            for issue in sorted_issues:
                                st.write(f"**Title:** {issue['title']}")
                                st.write(f"**Body:** {issue['body']}")
                                st.write(f"**User:** {issue['user']}")
                                st.write(f"**Created At:** {issue['created_at']}")
                                st.write(f"**Updated At:** {issue['updated_at']}")
                                st.write(f"**URL:** [Link]({issue['url']})")
                                st.write("---")
                        else:
                            st.write("No issues found.")
                            st.write("---")
                    
                    if display_prs:
                        st.write("### All Pull Requests:")
                        if sorted_prs:
                            for pr in sorted_prs:
                                st.write(f"**Title:** {pr['title']}")
                                st.write(f"**Body:** {pr['body']}")
                                st.write(f"**User:** {pr['user']}")
                                st.write(f"**State:** {pr['state']}")
                                st.write(f"**Created At:** {pr['created_at']}")
                                st.write(f"**Updated At:** {pr['updated_at']}")
                                st.write(f"**URL:** [Link]({pr['url']})")
                                st.write("---")
                        else:
                            st.write("No pull requests found.")
                            st.write("---")
                    
                    if display_milestones:
                        st.write("### All Milestones:")
                        if sorted_milestones:
                            for milestone_title, details in sorted_milestones:
                                st.write(f"**Milestone Title:** {milestone_title}")
                                st.write(f"**State:** {details['state']}")
                                st.write(f"**Due on:** {details['due_on']}")
                                st.write(f"**Description:** {details['description']}")
                                st.write(f"**URL:** [Link]({details['url']})")
                                st.write("---")
                        else:
                            st.write("No milestones found.")
                            st.write("---")
        else:
            st.write("No repositories found for this organization.")

    except Exception as e:
        st.error(f"Error fetching repositories or issues: {e}")