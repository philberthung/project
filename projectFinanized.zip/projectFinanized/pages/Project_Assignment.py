import streamlit as st
import requests
import os
import json
from dotenv import load_dotenv
from datetime import datetime, time
from pymongo import MongoClient
from pymongo.server_api import ServerApi
import pandas as pd

# Load environment variables
load_dotenv()

# MongoDB connection
uri = "mongodb+srv://nata:isd2025@isdcluster.jnn9ctb.mongodb.net/?appName=ISDcluster"
client = MongoClient(uri, server_api=ServerApi('1'))
db = client.students_database

# GitHub Classroom setup
CLASSROOM_TOKEN = os.getenv("GITHUB_TOKEN")
HEADERS = {
    "Authorization": f"Bearer {CLASSROOM_TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28"
}

def safe_api_call(url, description="data"):
    """Generic safe API call handler"""
    try:
        response = requests.get(url, headers=HEADERS)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as errh:
        st.error(f"HTTP Error ({description}): {errh}")
    except requests.exceptions.ConnectionError as errc:
        st.error(f"Connection Error ({description}): {errc}")
    except requests.exceptions.Timeout as errt:
        st.error(f"Timeout Error ({description}): {errt}")
    except requests.exceptions.RequestException as err:
        st.error(f"Request Error ({description}): {err}")
    except Exception as e:
        st.error(f"Unexpected error fetching {description}: {str(e)}")
    return None

def list_classrooms():
    """Fetch list of classrooms from GitHub Classroom API"""
    classrooms = safe_api_call(
        "https://api.github.com/classrooms",
        "classrooms"
    )
    if classrooms:
        for classroom in classrooms:
            classroom.setdefault('name', 'Unnamed Classroom')
            classroom.setdefault('id', '')
        return classrooms
    return None

def list_assignments(classroom_id):
    """Fetch assignments for a specific classroom with robust error handling"""
    if not classroom_id:
        st.error("No classroom ID provided")
        return None
        
    assignments = safe_api_call(
        f"https://api.github.com/classrooms/{classroom_id}/assignments",
        f"assignments for classroom {classroom_id}"
    )
    
    if assignments:
        for assignment in assignments:
            assignment.setdefault('title', 'Untitled Assignment')
            assignment.setdefault('id', '')
            assignment.setdefault('created_at', 'Unknown')
            assignment.setdefault('deadline', 'Not set')
            assignment.setdefault('invite_link', '#')
            assignment.setdefault('repo_url', 'Not available')
        return assignments
    return None

def get_assignment_details(assignment_id):
    """Get details for a specific assignment with error handling"""
    if not assignment_id:
        st.error("No assignment ID provided")
        return None
        
    details = safe_api_call(
        f"https://api.github.com/assignments/{assignment_id}",
        f"details for assignment {assignment_id}"
    )
    
    if details:
        details.setdefault('title', 'Untitled Assignment')
        details.setdefault('id', assignment_id)
        details.setdefault('invite_link', '#')
        details.setdefault('created_at', 'Unknown')
        return details
    return None

def check_all_classroom_assignments():
    """Display all assignments across all classrooms with safe field access"""
    st.subheader("All Classroom Assignments")
    
    with st.spinner("Fetching all classrooms and assignments..."):
        classrooms = list_classrooms()
        if not classrooms:
            st.warning("No classrooms found")
            return
            
        for classroom in classrooms:
            with st.expander(f"Classroom: {classroom['name']} (ID: {classroom['id']})"):
                assignments = list_assignments(classroom['id'])
                if not assignments:
                    st.info("No assignments in this classroom")
                    continue
                    
                st.write(f"**Total Assignments:** {len(assignments)}")
                for assignment in assignments:
                    st.markdown(f"""
                    - **Title:** {assignment['title']}
                    - **ID:** {assignment['id']}
                    - **Created At:** {assignment['created_at']}
                    - **Deadline:** {assignment['deadline']}
                    - **Repo URL:** {assignment['repo_url']}
                    - **Invite Link:** [Student Link]({assignment['invite_link']})
                    """)
                    st.divider()

def teacher_view():
    st.title("GitHub Classroom Manager")

    # Display user info
    if "username" not in st.session_state:
        st.session_state.username = ""  # Initialize username
    st.sidebar.write(f"Logged in as: {st.session_state.username}")
    st.sidebar.write(f"Role: Teacher")
    
    tab1, tab2 = st.tabs(["Link New Assignment", "View All Assignments"])
    
    with tab1:
        st.header("Link New Assignment to System")
        
        if st.button("Fetch Classrooms"):
            with st.spinner("Loading classrooms..."):
                classrooms = list_classrooms()
                if classrooms:
                    st.session_state.classrooms = classrooms
                    st.success(f"Found {len(classrooms)} classrooms!")
                else:
                    st.error("Failed to fetch classrooms")

        if 'classrooms' in st.session_state:
            classroom_options = {c['name']: c for c in st.session_state.classrooms}
            selected_classroom = st.selectbox(
                "Select Classroom",
                options=list(classroom_options.keys())
            )
            classroom_id = classroom_options[selected_classroom]['id']

            if st.button("Fetch Assignments for Selected Classroom"):
                with st.spinner("Loading assignments..."):
                    assignments = list_assignments(classroom_id)
                    if assignments:
                        st.session_state.assignments = assignments
                        st.success(f"Found {len(assignments)} assignments!")
                    else:
                        st.error("No assignments found or failed to fetch")

        if 'assignments' in st.session_state and isinstance(st.session_state.assignments, list):
            assignment_options = {
                assignment['title']: assignment for assignment in st.session_state.assignments
            }
            selected_assignment = st.selectbox(
                "Select Assignment",
                options=list(assignment_options.keys())
            )
            selected_assignment_data = assignment_options[selected_assignment]

        if 'assignments' not in st.session_state:
            st.session_state.assignments = pd.DataFrame(columns=["Title", "Description", "Deadline"])


        st.subheader("Current Assignments")
        st.dataframe(st.session_state.assignments)
    
    with tab2:
        check_all_classroom_assignments()
        
        st.subheader("Currently Linked Assignments")
        try:
            linked_assignments = list(db.assignments.find())
            if not linked_assignments:
                st.info("No assignments have been linked yet")
            else:
                for assignment in linked_assignments:
                    due_date = assignment.get('deadline')
                    display_date = due_date.strftime("%Y-%m-%d") if due_date else "No deadline"
                    
                    with st.expander(f"{assignment.get('title', 'Untitled')} - Due: {display_date}"):
                        st.markdown(f"""
                        **Classroom ID:** {assignment.get('classroom_id', 'N/A')}
                        **Assignment ID:** {assignment.get('assignment_id', 'N/A')}
                        **Status:** {assignment.get('status', 'active')}
                        **Linked On:** {assignment.get('created_at', datetime.now()).strftime("%Y-%m-%d %H:%M")}
                        **Notes:** {assignment.get('additional_notes', 'None')}
                        """)
        except Exception as e:
            st.error(f"Error loading linked assignments: {str(e)}")

    # Logout button
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.role = None
        st.session_state.username = None
        st.switch_page("Login_Page.py")

def student_view():
    st.title("Available Assignments")
    
    # Display user info
    if "username" not in st.session_state:
        st.session_state.username = ""  # Initialize username
    st.sidebar.write(f"Logged in as: {st.session_state.username}")
    st.sidebar.write(f"Role: Student")
    if 'permission' in st.session_state:
        st.sidebar.write(f"Permission: {st.session_state.permission.capitalize()}")
    
    try:
        assignments = list(db.assignments.find({"status": "active"}))
        
        if not assignments:
            st.info("No assignments available yet")
            return
            
        for assignment in assignments:
            due_date = assignment.get('deadline')
            display_date = due_date.strftime("%Y-%m-%d") if due_date else "No deadline"
            
            with st.expander(f"{assignment.get('title', 'Untitled Assignment')} - Due: {display_date}"):
                st.markdown(f"""
                **Instructions:**  
                {assignment.get('additional_notes', 'No additional instructions')}
                
                **Invite Link:** [Accept Assignment]({assignment.get('invite_link', '#')})  
                **Deadline:** {display_date}
                """)
                
                if assignment.get('deadline') and assignment['deadline'] < datetime.now():
                    st.warning("This assignment is past its deadline")

    except Exception as e:
        st.error(f"Error loading assignments: {str(e)}")

    # Logout button
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.role = None
        st.session_state.username = None
        st.switch_page("Login_Page.py")

def main():
    # Check if user is logged in
    if not st.session_state.get("logged_in"):
        st.warning("Please login first")
        st.switch_page("Login_Page.py")
        return
    
    # Show appropriate view based on role
    if st.session_state.get("role") == "teacher":
        teacher_view()
    elif st.session_state.get("role") == "student":
        student_view()
    else:
        st.error("Unauthorized access")
        st.switch_page("Login_Page.py")

if __name__ == "__main__":
    main()