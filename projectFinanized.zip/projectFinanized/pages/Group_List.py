import streamlit as st
import pandas as pd
from pymongo import MongoClient
from pymongo.server_api import ServerApi

# MongoDB connection
uri = "mongodb+srv://nata:isd2025@isdcluster.jnn9ctb.mongodb.net/?appName=ISDcluster"
client = MongoClient(uri, server_api=ServerApi('1'))

# Check connection
try:
    client.admin.command('ping')
except Exception as e:
    st.error(f"Could not connect to MongoDB: {e}")
    st.stop()  # Stop execution if MongoDB connection fails

# Access the database and collection
db = client.students_database
students_collection = db.students

# Load student data
students_data = list(students_collection.find({}))
students_df = pd.DataFrame(students_data)

# --- Data Cleaning ---
# Replace empty strings with None and drop rows where 'group' is None
students_df['group'] = students_df['group'].replace(" ", None)
students_df = students_df.dropna(subset=['group'])

# Convert group numbers to integers
try:
    students_df['group'] = students_df['group'].astype(int)
except ValueError as e:
    st.error(f"Error converting group numbers to integers: {e}")
    st.stop()

# --- Find students without a group ---
empty_group_students = list(students_collection.find({'group': " "}))
student_names_empty_group = [student.get('netid') for student in empty_group_students]

# --- User Authentication and Authorization ---
if 'logged_in' in st.session_state and st.session_state.logged_in and 'netid' in st.session_state:
    netid = st.session_state.netid
    user_data = students_df[students_df['netid'] == netid]

    if user_data is not None and not user_data.empty:
        username = user_data['id'].iloc[0]
        groups = user_data['group'].iloc[0]
        permission = user_data['permission'].iloc[0]
        role = user_data['role'].iloc[0]

        if permission in ['member']:
            st.error("You do not have permission to access this page.")
            st.stop()

        # --- Streamlit UI - Group Selection ---
        st.title("Group List")

        existing_groups = students_df['group'].unique().tolist()
        existing_groups.sort()

        group_number = None  # Initialize group_number

        if groups == 0:
            # User can select from all existing groups
            selected_group = st.selectbox("Select a Group", options=existing_groups)
            group_number = selected_group
        else:
            # User is restricted to their own group
            group_number = int(groups)
            st.write(f"You are assigned to Group {group_number}.")

        # --- Display Group Information ---
        if group_number is not None:
            try:
                # Get the students in the specified group
                group_students = students_df[students_df['group'] == group_number]

                # Extract the netids and names of the students
                student_info = []
                for index, row in group_students.iterrows():
                    student_info.append({'netid': row['netid'], 'name': row['name']})
                student_count = len(student_info)

                st.write(f"Number of students in Group {group_number} : {student_count}")
                st.write(f"Current students in Group {group_number}:")
                if student_info:
                    for student in student_info:
                        st.write(f"NetID: {student['netid']}, Name: {student['name']}")
                else:
                    st.write("No students found in this group.")

                # --- Add students to group functionality ---
                if student_count < 4:  # Only show if student_count is NOT 4
                    selected_students = st.multiselect("Select students to add to this group (MAX: 4):", options=student_names_empty_group)
                    selected_netids = selected_students
                    selected_count = len(selected_netids)  # Count the selected students
                    st.write(f"You selected {selected_count} students:", selected_students) #display the count
                    
                    if (selected_count+student_count) <=4:

                        if st.button("Add Students"):
                            # selected_emails = selected_students[selected_students['email'].isin(selected_students)]['email'].tolist() # Incorrect
                            selected_netids = selected_students  # selected_students is already a list of netids

                            # Update the database to assign the selected students to the group
                            for netid in selected_netids:
                                students_collection.update_one(
                                    {'netid': netid},  # Use 'netid' instead of 'email'
                                    {'$set': {'group': group_number}}  # Use group_number
                                )

                            st.success(f"Added students to group {group_number}: {selected_netids}")

                            # Rerun the app to refresh the data
                            st.rerun()
                    else:
                        st.write("You cannot choose more than 4 students.")  # Optional message
                else:
                    st.write("This group is full (4 students).  No more students can be added.")  # Optional message

            except Exception as e:
                st.error(f"An error occurred while retrieving group information: {e}")
        else:
            st.warning("Please select a group to view information.")

    else:
        st.error("User data not found.")

else:
    st.write("Please log in to access this page.")